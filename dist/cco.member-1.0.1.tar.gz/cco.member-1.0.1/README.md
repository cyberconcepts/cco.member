# Introduction

This is one of a series of Python packages for
the Zope-based knowledge management platform 
[loops](http://www.cyberconcepts.de) (in German).

It contains functionalities for registration and 
authentication of members of a loops site. 

There will be new modules as well as modules migrated from 
the current loops and cybertools repositories.

For more information see
[www.cyberconcepts.org](https://www.cyberconcepts.org).

More to come...
